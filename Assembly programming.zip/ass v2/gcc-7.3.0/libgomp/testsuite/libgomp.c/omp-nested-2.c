// { dg-do run }
// { dg-additional-options "-fipa-pta" }

#include "omp-nested-1.c"
