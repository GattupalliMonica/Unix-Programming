// { dg-do run { target lto } }
// { dg-additional-options "-fipa-pta -flto -flto-partition=max" }

#include "omp-nested-1.c"
