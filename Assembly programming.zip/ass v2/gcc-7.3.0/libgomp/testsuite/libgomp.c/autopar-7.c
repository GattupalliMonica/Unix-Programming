/* { dg-do run } */
/* { dg-additional-options "-ftree-parallelize-loops=4 -ffast-math --param parloops-schedule=auto" } */

#include "autopar-1.c"
