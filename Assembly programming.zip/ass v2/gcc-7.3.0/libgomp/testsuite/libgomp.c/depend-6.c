/* { dg-set-target-env-var OMP_NUM_THREADS "1" } */

#include "depend-1.c"
