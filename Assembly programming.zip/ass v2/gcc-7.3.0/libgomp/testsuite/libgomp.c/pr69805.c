/* PR driver/69805 */
/* { dg-do link } */
/* { dg-options "-ftree-parallelize-loops=1 -O2 -ftree-parallelize-loops=2" } */

int
main ()
{
  return 0;
}
